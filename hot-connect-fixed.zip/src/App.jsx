export default function App() {
  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(to bottom, #020617, #0f172a)",
      color: "white",
      fontFamily: "Arial",
      padding: "30px"
    }}>
      <h1>Hot Connect Kenya</h1>
      <p>Verified dating platform for professionals in Kenya</p>

      <div style={{marginTop: 20, padding: 20, background: "#1e293b", borderRadius: 12}}>
        <h2>Sample Matches</h2>
        <p>👩 Amina • Lawyer • Kilimani</p>
        <p>👨 Brian • Founder • Westlands</p>
        <p>👩 Faith • Architect • Karen</p>
      </div>

      <div style={{marginTop: 20}}>
        <h2>Plans</h2>
        <p>Free / Premium / VIP</p>
      </div>

      <footer style={{marginTop: 40, opacity: 0.6}}>
        Hot Connect • Real Connections in Kenya
      </footer>
    </div>
  )
}
